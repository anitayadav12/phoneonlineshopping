

package controller;
import java.io.*;
import java.sql.*;
import javax.servlet.http.*;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.register;
import DAO.registerdao; 
import java.sql.DriverManager;

public class registerservlet extends HttpServlet {

 protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
     response.setContentType("text/html");  
PrintWriter out = response.getWriter();  
     String fullName = request.getParameter("fullname");
 String email = request.getParameter("email");
 String userName = request.getParameter("username");
 String password = request.getParameter("password");
 String repassword = request.getParameter("repassword");
  try{
     Class.forName("com.mysql.jdbc.Driver");  
Connection con=DriverManager.getConnection(  
"jdbc:mysql://localhost:3306/anita","root","root");  
         PreparedStatement ps=con.prepareStatement(  
"insert into register1 values(?,?,?,?,?)");  
  
ps.setString(1,fullName);  
ps.setString(2,email);  
ps.setString(3,userName);  
ps.setString(4,password);  
ps.setString(5,repassword);  

          
int i=ps.executeUpdate();  
if(i>0)  
out.print("You are successfully registered...");  
  }
  catch(Exception e){
      System.out.println(e);
  }
 }}


 
    
  

