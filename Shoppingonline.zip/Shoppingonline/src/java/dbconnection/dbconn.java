

package dbconnection;

import java.sql.Connection;
import java.sql.DriverManager;
 
public class dbconn {
    public static Connection createConnection()
 {
 Connection con = null;
 String url = "jdbc:mysql://anita"; 
         
 String username = "root"; 
 String password = "root"; 
 
 try 
 {
 try 
 {
 Class.forName("com.mysql.jdbc.Driver");  
 } 
 catch (ClassNotFoundException e)
 {
 e.printStackTrace();
 }
 
 con = DriverManager.getConnection(url, username, password); //attempting to connect to MySQL database
 System.out.println("Printing connection object "+con);
 } 
 catch (Exception e) 
 {
 e.printStackTrace();
 }
 
 return con; 
 }
}



