

package DAO;

 
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import model.register;
import dbconnection.dbconn;

 
public class registerdao {
    public String registeruser(register registerbean){
    
String fullName = registerbean.getFullName();
String email = registerbean.getEmail();
String userName = registerbean.getUserName();
String password = registerbean.getPassword();
Connection con = null;
PreparedStatement preparedStatement = null;
try
{
con = dbConnection.createConnection();
String query = "insert into register1(fullName,Email,userName,password) values (?,?,?,?)"; //Insert user details into the table 'USERS'
preparedStatement = con.prepareStatement(query); //Making use of prepared statements here to insert bunch of data
preparedStatement.setString(1, fullName);
preparedStatement.setString(2, email);
preparedStatement.setString(3, userName);
preparedStatement.setString(4, password);
int i= preparedStatement.executeUpdate();
if (i!=0)  //Just to ensure data has been inserted into the database
return "SUCCESS"; 
}
catch(SQLException e)
{
e.printStackTrace();
}
return "Oops.. somethng went wrong there..! ";
        }

    public String registerUser(register registerBean) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private static class dbConnection {

        private static Connection createConnection() {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

        public dbConnection() {
        }
    }
    }
   

